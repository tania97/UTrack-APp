package layout;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jordan.lucie.utrackapp.DetailsActivity;
import com.jordan.lucie.utrackapp.ListViewActivity;
import com.jordan.lucie.utrackapp.MyAdaptor;
import com.jordan.lucie.utrackapp.R;
import com.jordan.lucie.utrackapp.UTrackObject;

import java.util.ArrayList;

import static android.content.ContentValues.TAG;

/**
 * Created by group 1
 *
 * @author group 1
 *         <p>
 *         <p>
 *         A simple {@link Fragment} subclass.
 *         Activities that contain this fragment must implement the
 *         {@link ListViewFragment.OnFragmentInteractionListener} interface
 *         to handle interaction events.
 *         Use the {@link ListViewFragment#newInstance} factory method to
 *         create an instance of this fragment.
 * @version 1.0
 */
public class ListViewFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private static final int REQUEST_CODE_DETAILS = 10;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private MyAdaptor myAdaptor;

    private DatabaseReference mDatabase;
    private FirebaseAuth auth;

    ListView trackList;
    ArrayList<UTrackObject> uTrackObjects;

    private OnFragmentInteractionListener mListener;

    public ListViewFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ListViewFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ListViewFragment newInstance(String param1, String param2) {
        ListViewFragment fragment = new ListViewFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list_view, container, false);

        auth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference(); //Her opretter vi en instans af databasen
        mDatabase.addValueEventListener(myListener);

        //uTrackObjects = new ArrayList<UTrackObject>();

        trackList = (ListView) view.findViewById(R.id.layout_list_view);
        myAdaptor = new MyAdaptor(this.getContext(), uTrackObjects);
        trackList.setAdapter(myAdaptor);

        trackList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent uTrackIntent = new Intent(getContext(), DetailsActivity.class);

                uTrackIntent.putExtra("name", uTrackObjects.get(position).getName());
                uTrackIntent.putExtra("latitude", uTrackObjects.get(position).getLatitude());
                uTrackIntent.putExtra("longitude", uTrackObjects.get(position).getLongitude());
                uTrackIntent.putExtra("notes", uTrackObjects.get(position).getNotes());

                startActivityForResult(uTrackIntent, REQUEST_CODE_DETAILS);
            }
        });

        // Inflate the layout for this fragment
        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    //https://firebase.google.com/docs/database/android/lists-of-data
    ValueEventListener myListener = new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot dataSnapshot) {
            Iterable<DataSnapshot> keyObjects = dataSnapshot.getChildren();
            UTrackObject uTrackObject;
            uTrackObjects = new ArrayList<UTrackObject>();
            for (DataSnapshot sd : keyObjects) {
                uTrackObject = sd.getValue(UTrackObject.class);
                if (uTrackObject != null) {
                    uTrackObjects.add(uTrackObject);
                }
            }

            myAdaptor.setuTrackObjectsArrayList(uTrackObjects);
            myAdaptor.notifyDataSetChanged();

        }

        @Override
        public void onCancelled(DatabaseError databaseError) {
            Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
        }
    };
}
